package com.Call_Assist;

public class ForegroundService extends com.worklight.androidgap.WLForegroundService{
	//Nothing to do here...
}