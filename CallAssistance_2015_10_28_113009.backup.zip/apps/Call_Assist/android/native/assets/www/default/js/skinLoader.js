
/* JavaScript content from js/skinLoader.js in folder common */
