/** Automatically generated file. DO NOT MODIFY */
package com.Call_Assist;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}